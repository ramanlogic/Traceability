# Refactoring - The Game of Life

## Build

Build and write baseline file:
```shell
(cmake -B build  . |ccze -A -o nolookups) && (cmake --build build/ 2>&1  | ccze -A -o nolookups) &&  ./build/game-of-life/game-of-life > build/baseline.txt
```

Build new change, write results to check-file (see acceptance tests) and compare to baseline:
```shell
(cmake -B build  . |ccze -A -o nolookups) && (cmake --build build/ 2>&1  | ccze -A -o nolookups) &&  ./build/game-of-life/game-of-life > build/change.txt && diff build/baseline.txt build/change.txt
```

If results differ, the diff is shown otherwise no additional output is given.
