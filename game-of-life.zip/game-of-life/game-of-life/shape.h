#pragma once

struct Shape
{
public:
    char xCoord;
    char yCoord;
    char height;
    char width;
    char** figure;
};
