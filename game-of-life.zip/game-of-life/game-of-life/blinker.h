#pragma once

#include "shape.h"


struct Blinker : public Shape
{
    static const char BLINKER_HEIGHT = 3;
    static const char BLINKER_WIDTH = 1;
    Blinker(char x, char y);
    ~Blinker();
};
