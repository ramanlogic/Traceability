#include <iostream>
#include <vector>

#include "game-of-life.h"
#include "glider.h"
#include "blinker.h"


int main()
{
    Glider glider(0, 0);
    GameOfLife gol(glider);
    gol.iterate(5);
    Blinker blinker(1, 0);
    GameOfLife gol2(blinker);
    gol2.iterate(4);
}