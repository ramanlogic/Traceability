#pragma once

#include "shape.h"


struct Glider : public Shape
{
    static const char GLIDER_SIZE = 3;
    Glider(char x, char y);
    ~Glider();
};
