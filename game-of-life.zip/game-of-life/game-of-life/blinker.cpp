#include "blinker.h"

Blinker::Blinker(char x, char y)
{
    xCoord = x;
    yCoord = y;
    height = BLINKER_HEIGHT;
    width = BLINKER_WIDTH;
    figure = new char*[BLINKER_HEIGHT];
    for (int i = 0; i < BLINKER_HEIGHT; i++) {
        figure[i] = new char[BLINKER_WIDTH];
    }
    for (int i = 0; i < BLINKER_HEIGHT; i++) {
        for (int j = 0; j < BLINKER_WIDTH; j++) {
            figure[i][j] = 'X';
        }
    }
}

Blinker::~Blinker()
{
    for (int i = 0; i < BLINKER_HEIGHT; i++) {
        delete[] figure[i];
    }
    delete[] figure;
}
