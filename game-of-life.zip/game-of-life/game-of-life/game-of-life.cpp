﻿#include <functional>
#include <iostream>
#include <vector>

#include "game-of-life.h"

GameOfLife::GameOfLife(Shape sh)
    : shape(sh)
    , toggle(true)
{
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            world[i][j] = '.';
        }
    }
    for (int i = shape.yCoord; i - shape.yCoord < shape.height; i++) {
        for (int j = shape.xCoord; j - shape.xCoord < shape.width; j++) {
            if (i < HEIGHT && j < WIDTH) {
                world[i][j] = shape.figure[i - shape.yCoord][j - shape.xCoord];
            }
        }
    }
}

void GameOfLife::print()
{
    if (toggle) {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                std::cout << world[i][j];
            }
            std::cout << std::endl;
        }
    }
    else {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                std::cout << otherWorld[i][j];
            }
            std::cout << std::endl;
        }
    }
    for (int i = 0; i < WIDTH; i++) {
        std::cout << '=';
    }
    std::cout << std::endl;
}

void GameOfLife::update()
{
    if (toggle) {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                otherWorld[i][j] = GameOfLife::getState(world[i][j], i, j, toggle);
            }
        }
        toggle = !toggle;
    }
    else {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                world[i][j] = GameOfLife::getState(otherWorld[i][j], i, j, toggle);
            }
        }
        toggle = !toggle;
    }
}

char GameOfLife::getState(char state, char yCoord, char xCoord, bool shall_toggle)
{
    char neighbors = 0;
    if (shall_toggle) {
        for (int i = yCoord - 1; i <= yCoord + 1; i++) {
            for (int j = xCoord - 1; j <= xCoord + 1; j++) {
                if (i == yCoord && j == xCoord) {
                    continue;
                }
                if (i > -1 && i < HEIGHT && j > -1 && j < WIDTH) {
                    if (world[i][j] == 'X') {
                        neighbors++;
                    }
                }
            }
        }
    }
    else {
        for (int i = yCoord - 1; i <= yCoord + 1; i++) {
            for (int j = xCoord - 1; j <= xCoord + 1; j++) {
                if (i == yCoord && j == xCoord) {
                    continue;
                }
                if (i > -1 && i < HEIGHT && j > -1 && j < WIDTH) {
                    if (otherWorld[i][j] == 'X') {
                        neighbors++;
                    }
                }
            }
        }
    }
    if (state == 'X') {
        return (neighbors > 1 && neighbors < 4) ? 'X' : '.';
    }
    else {
        return (neighbors == 3) ? 'X' : '.';
    }
}

void GameOfLife::iterate(int iterations)
{
    for (int i = 0; i < iterations; i++) {
        print();
        update();
    }
}
