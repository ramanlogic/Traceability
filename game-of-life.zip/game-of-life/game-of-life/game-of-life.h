﻿#pragma once

#include "shape.h"

#define HEIGHT 4
#define WIDTH 4

class GameOfLife {
public:
    GameOfLife(Shape sh);
    void print();
    void update();
    char getState(char state, char xCoord, char yCoord, bool toggle);
    void iterate(int iterations);

private:
    char world[HEIGHT][WIDTH];
    char otherWorld[HEIGHT][WIDTH];
    Shape shape;
    bool toggle;
};
