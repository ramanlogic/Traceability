# Clean Code Workshop - Example 1

Look at the code in `source.cpp`. Try to answer the following questions:

- What does the whole program do?
- What issues can you find with the code?
- How can it be improved?
- Assume that this is part of a bigger program. What may change?
    + In which way can you improve the code to be more robust against those changes?

## Build

In order to compile, use the following command:

```shell
cmake -B build . && cmake --build build/
```

Use the following command to get a list of available configuration options.
```shell
cmake . -LH
```

## Run
The output binary is created in the `build` folder. It's named `clean-code`. To run it call:

```shell
./build/src/clean-code
```

## Build and Run
Build sources, clear terminal so that output can be easily discerned from build output.

```shell
cmake -DENABLE_ANALYSIS_CLANG_TIDY=OFF -B build . && cmake --build build/ && ./build/src/clean-code
```

## SPOILERS: Annotated source

```cpp
   int arr[] = {34, 1, 12, 77, 98, 3, 44, 65, 42};
   // size of the array is just a magic number, if array size changes the count
   // needs to be manually adapted, as long as it is an array, the
   // sizeof(arr)/sizeof(arr[0]) pattern would work.
   int n = 9;

   // What does this do? It's not immediately obvious.
   // Extracting it to a function called "sort" will greatly improve
   // understandability
   for (int i = 0; i < n - 1; i++)
   {
      for (int j = 0; j < n - i - 1; j++)
      {
         if (arr[j] > arr[j + 1])
         {
            int temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;
         }
      }
   }

   // wait there's more. This only considers the first 3 elements of the sorted
   // array. A bit tricky that it is "hiding" the fact that we're interested in
   // only the first 3 element inside the for-loop, using a constant and
   // extracting to a function might be much more readable.
   for (int i = 0; i < 3; ++i)
      std::cout << arr[i] << ", ";

```