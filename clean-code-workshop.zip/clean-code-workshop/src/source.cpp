#include <algorithm>
#include <iostream>


int main()
{
   int arr[] = {34, 1, 12, 77, 98, 3, 44, 65, 42};
   int n = 9;

   for (int i = 0; i < n - 1; i++)
   {
      for (int j = 0; j < n - i - 1; j++)
      {
         if (arr[j] > arr[j + 1])
         {
            int temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;
         }
      }
   }

   for (int i = 0; i < 3; ++i)
      std::cout << arr[i] << ", ";

   std::cout << "\n";
   std::cout << "done\n\n";
   return 0;
}
