# Game of life - Design Considerations

> [!WARNING]
>
> This is the messy branch of changes being made and new things to take care being discovered and addressed. Note that this is an accurate reflection of how things work. The cleaned up version will be much more easier to understand but suggest a level of clarity and vision that is far from reality.

There are many design changes that can be considered for this program.
The main question is, which design aspects will benefit the program.

So what does that mean?
Well, the goal of a software desing/architecture is to ensure that things that are likely to change can be changed without impacting the rest of the code.


## What is likely to be changed?

Looking at examples for the use of [game of life](https://youtu.be/6avJHaC3C2U?feature=shared&t=270), most likely changes are:
- Output type
- Playfield size
- Storing and loading of states
- Complex Playfield initialization

Complexities are going to arise from very large play-fields as they will be very slow to generate, even if nothing is in them.

So let's start with those three aspects.
Not necessarily in that order.

## Flexible Output
Originally the output was tied to the game.
While that is fine when we quickly want to show that things are working, any change to our output requirements requires us to touch the game code.
For that reason we extract the output function into a so called `strategy` pattern and pass the output function into the game object.
That way the game object does not care about the way we are providing output.
This is really helpful when switching output e.g. from console to a graphics engine.

## Playfield Size

First step for refactoring was to separate the playing field from the game to make it simpler to handle.
That involved passing a `builder` function into the game object.
The idea behind that was, that we are likely to have some specialized needs to create a playing field later on.

Moving on to the playfield size itself.

### Experiment: Dynamic vs. Static
Design consideration:
Playfield size can either be fixed size allowing for more optimization based on fixed sizes, while dynamic size allows for much more flexibility in playfield sizes.

So let's determine performance difference between constant and dynamic playing field size.
A cursory experiment of 100 iterations on a 1024x1024 playing field showed the following results:

| Implementation     | time (ms) |
|--------------------|-----------|
| Static field size  |      1514 |
| Dynamic field size |      1185 |

The difference between static and dynamic size is surprisingly in favor of dynamic allocation.
Even with loading the playfield size from file.
Here we could spend some more time, why this is happening but it's not really worth investigating, since we need to go dynamic anyways.

> [!NOTE]
>
> This was an unnecessary rabbit hole to fall into, since compile-time constant playfield size would not have been feasible anyways. But good to know that it wouldn't make a difference. Lesson learned: Be careful of sidetracks that are not contributing to your problem.

With that concern out of the way, we can fully commit to dynamic field sizes.

### Implementing Dynamic Field Size
Instead of having `width` and `height` as constants in the header, I chose to pass them as parameters to the constructor.
Reason for this is, that a playfield shall always be constructed with well defined dimensions.

Now we can see that we need to find a way to pass the configuration of the playing field to the world builder.
Good thing that I extracted world building from the game code.
So all changes are only happening in the builder function.
At first I chose to implement a basic hack for the experiment.
Loading the configuration directly from the file in the world builder function.


## Complex Playfield Initilization

Complex playfield initialization means that we are likely to have scenarios where the user would want to create pre-populated playing fields.
Instead of using objects containing pattern, I chose to create "placement"-functions, that allow putting shapes directly onto the playing field without creating a lot of redundant objects.

Note that shapes now have a dependency to the playfield.
This is an intentional decision.
We are not expecting to gain much from additional abstraction from the playing field.
If we experience any pain points later on, we can alway add another abstraction.

## Storing and loading of playfields
> [!NOTE]
>
> [Postponed due to time constraints]


## Build

Build and write baseline file:
```shell
(cmake -B build  . |ccze -A -o nolookups) && (cmake --build build/ 2>&1  | ccze -A -o nolookups) &&  ./build/game-of-life/game-of-life > build/baseline.txt
```

Build new change, write results to check-file (see acceptance tests) and compare to baseline:
```shell
(cmake -B build  . |ccze -A -o nolookups) && (cmake --build build/ 2>&1  | ccze -A -o nolookups) &&  ./build/game-of-life/game-of-life > build/change.txt && diff build/baseline.txt build/change.txt
```

If results differ, the diff is shown otherwise no additional output is given.
