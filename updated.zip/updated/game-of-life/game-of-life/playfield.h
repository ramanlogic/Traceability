#pragma once

#include "coordinates.h"
#include <cstddef>
#include <vector>

static constexpr char DEAD = '.';
static constexpr char ALIVE = 'X';

class Playfield_t {
public:
    Playfield_t(size_t new_width, size_t new_height);

    int get_neighbour_count(X_coord x, Y_coord y) const noexcept;
    void set(X_coord x, Y_coord y, char value) noexcept;
    char get(X_coord x, Y_coord y) const noexcept;
    void swap(Playfield_t& other) noexcept;

    size_t get_height() const noexcept;
    size_t get_width() const noexcept;

private:
    size_t to_index(size_t x, size_t y) const noexcept;

    size_t width = 0;
    size_t height = 0;
    std::vector<char> field;
};
