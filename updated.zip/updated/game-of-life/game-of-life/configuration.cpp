#include "configuration.h"
#include <fstream>
#include <string>

Configuration load_configuration()
{
    std::ifstream file("field.txt");
    std::string width_text;
    std::string height_text;

    std::getline(file, width_text);
    std::getline(file, height_text);
    const size_t width = atoi(width_text.c_str());
    const size_t height = atoi(height_text.c_str());

    return { width, height };
}
