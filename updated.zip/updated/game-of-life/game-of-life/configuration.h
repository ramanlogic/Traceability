#pragma once
#include <cstddef>

struct Configuration {
    size_t width = 1024;
    size_t height = 1024;
};

Configuration load_configuration();