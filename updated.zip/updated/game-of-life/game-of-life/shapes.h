#pragma once
#include "coordinates.h"
#include <cstddef>

class Playfield_t;

void put_glider(Playfield_t& playfield, X_coord x, Y_coord y);
void put_blinker(Playfield_t& playfield, X_coord x, Y_coord y);
