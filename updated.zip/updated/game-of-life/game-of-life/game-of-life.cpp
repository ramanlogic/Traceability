﻿#include "game-of-life.h"

#include <functional>
#include <iostream>
#include <vector>

static char get_new_state(const Playfield_t& playfield, X_coord x, Y_coord y)
{
    const auto neighbors = playfield.get_neighbour_count(x, y);
    const auto current_state = playfield.get(x, y);

    if (current_state == ALIVE) {
        if (neighbors > 1 && neighbors < 4) {
            return ALIVE;
        }
        else {
            return DEAD;
        }
    }

    // current_state == DEAD
    const auto is_born = neighbors == 3;
    if (is_born)
        return ALIVE;

    return DEAD;
}

GameOfLife::GameOfLife(WorldBuilder worldBuild, Output_strategy new_output)
    : playfield(worldBuild())
    , temp(playfield)
    , output(new_output)
{
}

void GameOfLife::print()
{
    output(playfield);
}

void GameOfLife::update()
{
    for (Y_coord y { 0 }; y < playfield.get_height(); ++y) {
        for (X_coord x { 0 }; x < playfield.get_width(); ++x) {
            const auto new_state = get_new_state(playfield, x, y);
            temp.set(x, y, new_state);
        }
    }

    playfield.swap(temp);
}

void GameOfLife::iterate(int iterations)
{
    for (int i = 0; i < iterations; i++) {
        print();
        update();
    }
}
