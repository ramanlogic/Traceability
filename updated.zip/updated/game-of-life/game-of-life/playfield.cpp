#include "playfield.h"

Playfield_t::Playfield_t(size_t new_width, size_t new_height)
    : width(new_width)
    , height(new_height)
    , field(std::vector<char>(width * height, DEAD))
{
}

size_t Playfield_t::to_index(size_t x, size_t y) const noexcept
{
    return x + (y * width);
}

/** Sets a given character at the given coordinate. Out of bounds values are silently ignored. */
void Playfield_t::set(X_coord x, Y_coord y, char value) noexcept
{
    if (x < width && y < height) {
        field[to_index(x, y)] = value;
    }
}

/** Sets a given character at the given coordinate. Out of bounds values are silently ignored. */
char Playfield_t::get(X_coord x, Y_coord y) const noexcept
{
    if (x >= width || y >= height)
        return DEAD;

    return field[to_index(x, y)];
}

int Playfield_t::get_neighbour_count(X_coord x, Y_coord y) const noexcept
{
    if (x >= width || y >= height)
        return 0;

    int neighbour_count = 0;

    for (Y_coord count_y = std::min(y, y - 1); count_y <= y + 1; ++count_y) {
        for (X_coord count_x = std::min(x, x - 1); count_x <= x + 1; ++count_x) {
            neighbour_count += (get(count_x, count_y) == ALIVE);
        }
    }

    if (get(x, y) == ALIVE) {
        // Don't count the reference field as we are only interested int the neighbors
        --neighbour_count;
    }

    return neighbour_count;
}

size_t Playfield_t::get_height() const noexcept
{
    return height;
}
size_t Playfield_t::get_width() const noexcept
{
    return width;
}

void Playfield_t::swap(Playfield_t& other) noexcept
{
    field.swap(other.field);
}
