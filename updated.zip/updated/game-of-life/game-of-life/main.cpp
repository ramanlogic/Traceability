#include <chrono>
#include <iostream>
#include <vector>

#include "configuration.h"
#include "game-of-life.h"
#include "shapes.h"

void print(const Playfield_t& /* field */)
{
    // for (size_t y = 0; y < Height; y++) {
    //     for (size_t x = 0; x < Width; x++) {
    //         std::cout << field.get(x, y);
    //     }
    //     std::cout << "\n";
    // }

    // for (size_t x = 0; x < Width; x++) {
    //     std::cout << '=';
    // }
    // std::cout << "\n";
}

void store(const Playfield_t& /* field */)
{
}

void combined(const Playfield_t& field)
{
    print(field);
    store(field);
}

Playfield_t init_field(Configuration play_config)
{
    Playfield_t field(play_config.width, play_config.height);

    put_glider(field, X_coord { 1 }, Y_coord { 1 });
    put_blinker(field, X_coord { 10 }, Y_coord { 1 });

    return field;
}

void play()
{
    constexpr int interations = 100;
    auto playfield_builder = []() { return init_field(load_configuration()); };

    GameOfLife gol(playfield_builder, combined);
    gol.iterate(interations);
}

int main()
{
    using namespace std::chrono;
    const auto start_time = steady_clock::now();

    play();

    const auto end_time = steady_clock::now();
    const auto duration_ms = duration_cast<milliseconds>(end_time - start_time);
    std::cerr << duration_ms.count() << "\n";
}