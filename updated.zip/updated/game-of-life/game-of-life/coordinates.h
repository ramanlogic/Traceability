#pragma once
#include <cstddef>

template <typename Tag> struct Base_coord {
    explicit Base_coord(size_t new_value)
        : value(new_value)
    {
    }

    operator size_t() const
    {
        return value;
    }

    Base_coord<Tag>& operator++()
    {
        value += 1;
        return *this;
    }

private:
    size_t value = 0;
};

template <typename Tag> Base_coord<Tag> operator+(Base_coord<Tag> lhs, int rhs)
{
    return Base_coord<Tag> { (size_t)lhs + rhs };
}

template <typename Tag> Base_coord<Tag> operator-(Base_coord<Tag> lhs, int rhs)
{
    return Base_coord<Tag> { (size_t)lhs - rhs };
}

struct X_tag { };
using X_coord = Base_coord<X_tag>;

struct Y_tag { };
using Y_coord = Base_coord<Y_tag>;
