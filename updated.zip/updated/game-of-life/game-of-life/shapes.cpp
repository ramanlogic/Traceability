#include "shapes.h"
#include "playfield.h"

void put_glider(Playfield_t& playfield, X_coord x, Y_coord y)
{
    // This looks like:
    //    ..x
    //    x.x
    //    .xx

    playfield.set(x + 0, y + 1, ALIVE);
    playfield.set(x + 1, y + 2, ALIVE);
    playfield.set(x + 2, y + 0, ALIVE);
    playfield.set(x + 2, y + 1, ALIVE);
    playfield.set(x + 2, y + 2, ALIVE);
}

void put_blinker(Playfield_t& playfield, X_coord x, Y_coord y)
{
    // This looks like:
    //    x..
    //    x..
    //    x..

    static const char BLINKER_HEIGHT = 3;

    for (X_coord new_x = x; new_x < BLINKER_HEIGHT; ++new_x) {
        playfield.set(new_x, y, ALIVE);
    }
}