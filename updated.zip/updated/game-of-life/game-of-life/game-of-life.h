﻿#pragma once

#include "playfield.h"
#include <functional>

using Output_strategy = std::function<void(Playfield_t&)>;

using WorldBuilder = std::function<Playfield_t()>;

class GameOfLife {
public:
    GameOfLife(WorldBuilder worldBuild, Output_strategy new_output);

    void print();
    void update();
    void iterate(int iterations);

private:
    Playfield_t playfield;
    Playfield_t temp; // keep alive for more efficient memory handling
    Output_strategy output;
};
